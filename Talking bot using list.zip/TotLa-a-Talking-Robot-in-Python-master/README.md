# Talking-Robot-in-Python
A fully functional Talking robot which can Listen, Decide and talk back.

V(1)
Watch the robot in action: https://www.youtube.com/watch?v=I46JJYlR0Lg
Written tutorial on https://www.instructables.com/id/TotLa-Interactive-Talking-Robot-in-Python3

# Work In Progress
Follow this to get update.
